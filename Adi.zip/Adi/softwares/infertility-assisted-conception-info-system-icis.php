<?php
$title = 'Einpoint - About';

?>
<?php
require_once 'inc/header.php';
?>


<div class="page-banner">
    <img src="../assets/img/page-banner.png" alt="Page Banner">
</div>
<div class="page-bg">



    <div class="page-wrapper ">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index"><span class="fa fa-home"></span>
                        Home</a></li>
                <li class=" breadcrumb-item active" aria-current="page"> COMPLETE INFERTILITY/ASSISTED CONCEPTION
                    INFORMATION SYSTEM </li>
            </ol>
        </nav>
    </div>

    <div class="page-wrapper soft-page">
        <h2>COMPLETE INFERTILITY/ASSISTED CONCEPTION INFORMATION SYSTEM (ICIS)</h2>

        <div class="row">
            <div class="col-sm-4">
                <img src="../assets/img/celiac-infertility.jpg" alt="COMPLETE INFERTILITY/ASSISTED CONCEPTION INFORMATION SYSTEM">
            </div>

            <div class="col-sm-8">
                <p>

                    These programs have been carefully designed to work in a stand-alone system or in a multi-user
                    environment and they can be purchased and used separately or as integrated software.
                </p>           
                
                <h3>They include the following:</h3>

                <ul>
                    <li>ICIS Database</li>
                    <li>Medical Records & Billing System</li>
                    <li>Human Resources Management System(Personnel/Payroll)</li>
                    <li>Enterprise Information System(EIS)</li>
                    <li>Stock/Inventory Control System</li>
                    <li>Accounts Payable System</li>
                    <li>Fixed Assets Management System</li>
                    <li>General Ledger Accounting System</li>


                </ul>

               


                

                
            </div>
        </div>




    </div>
</div>




<?php
require_once '../inc/footer.php';
?>