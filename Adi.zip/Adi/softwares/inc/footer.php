<footer style="background-color: #0e1a38;" class="text-light py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-3 mb-3">
                <h5>Explore</h5>
                <ul class="list-unstyled">
                    <li><a href="../index" class="text-light text-decoration-none">Home</a></li>
                    <li><a href="../contact" class="text-light text-decoration-none">Contact us</a></li>
                    <li><a href="../about" class="text-light text-decoration-none">About us</a></li>
                    <li><a href="../faq" class="text-light text-decoration-none">Faq</a></li>                  
                    <li><a href="#" class="text-light text-decoration-none">Blog</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 mb-3">
                <h5>Softwares</h5>
                <ul class="list-unstyled">
                    
                <li><a href="medical-healthcare-erp-software-intemeds" class="text-light text-decoration-none">
                Medical/Health Care ERP Software(INTEMEDS)</a>
                    </li>
                    <li><a href="accounting-finance-erp-software-adapack" class="text-light text-decoration-none">Accounting/Finance ERP Software(ADAPACK)</a></li>
                    <li><a href="point-of-sale-software-adapack-pos" class="text-light text-decoration-none">Point of Sale Software (ADAPACK POS)</a></li>

                    <li><a href="hotel-management-software" class="text-light text-decoration-none">Hotel Management Software</a></li>
                    <li><a href="infertility-assisted-conception-info-system-icis" class="text-light text-decoration-none">Infetility/Assited Conception Info.System(ICIS)</a></li>
                   
                </ul>
            </div>
            <div class="col-md-3 mb-3">
                <h5>Terms</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light text-decoration-none">Privacy Policy</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Security Policy</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Cookie Policy</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Child Protection
                            Policy</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Terms of Service</a></li>
                </ul>
            </div>
            <div class="col-md-3 mb-3">
                <h5>Contact Us</h5>
                <p><i class="bi bi-envelope"></i> info@adisystems.com.ng</p>
                <p><i class="bi bi-phone"></i> 080-3529-5090</p>
                <p><i class="bi bi-phone"></i> 080-2303-2959</p>
                <p><i class="bi bi-phone"></i> 080-7718-5893</p>
                <p><i class="bi bi-geo-alt"></i>156, Okota Road, Okota-Isolo, Lagos, Nigeria.</p>
                <div class="mt-3">
                    <a href="#" class="text-light me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-light me-3"><i class="bi bi-tiktok"></i></a>
                    <a href="#" class="text-light me-3"><i class="bi bi-whatsapp"></i></a>
                    <a href="#" class="text-light"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div style="background-color: #004085;" class="text-center text-white py-2 mt-3">
        <p class="mb-0">&copy; 2025 ADI Systems. All rights reserved.</p>
    </div>
</footer>
   
<script src="assets/js/addon.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.8/umd/popper.min.js"
    integrity="sha512-TPh2Oxlg1zp+kz3nFA0C5vVC6leG/6mm1z9+mA81MI5eaUVqasPLO8Cuk4gMF4gUfP5etR73rgU/8PNMsSesoQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js"
    integrity="sha512-ykZ1QQr0Jy/4ZkvKuqWn4iF3lqPZyij9iRv6sGqLRdTPkY69YX6+7wvVGmsdBbiIfN/8OdsI7HABjvEok6ZopQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/8.0.0/mdb.umd.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>