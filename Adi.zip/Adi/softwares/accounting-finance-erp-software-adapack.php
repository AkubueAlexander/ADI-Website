<?php
$title = 'Einpoint - About';

?>
<?php
require_once 'inc/header.php';
?>


<div class="page-banner">
    <img src="../assets/img/page-banner.png" alt="Page Banner">
</div>
<div class="page-bg">



    <div class="page-wrapper ">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index"><span class="fa fa-home"></span>
                        Home</a></li>
                <li class=" breadcrumb-item active" aria-current="page">Softwares/ ACCOUNTING/FINANCE ERP SOFTWARE </li>
            </ol>
        </nav>
    </div>

    <div class="page-wrapper soft-page">
        <h2>ACCOUNTING/FINANCE ERP SOFTWARE (ADAPACK)</h2>

        <div class="row">
            <div class="col-sm-4">
                <img src="../assets/img/erp.png" alt="ACCOUNTING/FINANCE ERP SOFTWARE">
            </div>

            <div class="col-sm-8">
                <p>

                    Our Integrated Business Management System (adA_PACK 5.0) is a stream of locally designed and
                    developed Enterprise Resource Planning Software in Nigeria that caters for all complexity and
                    flexibility required to manage a business outfit – valuable financial; and management information
                    readily available, with minimum hassle, to authorized personnel when required. The systems are
                    designed to fit into small and large companies, group of companies, marketing and production
                    outfits. Our Enterprise Resource Planning software is a a suite of integrated applications that an
                    organization can use to collect, store, manage, and interpret data from many business activities.
                </p>
            </div>
        </div>




    </div>
</div>




<?php
require_once '../inc/footer.php';
?>