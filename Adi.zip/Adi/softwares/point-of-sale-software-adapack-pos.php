<?php
$title = 'Einpoint - About';

?>
<?php
require_once 'inc/header.php';
?>


<div class="page-banner">
    <img src="../assets/img/page-banner.png" alt="Page Banner">
</div>
<div class="page-bg">



    <div class="page-wrapper">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index"><span class="fa fa-home"></span>
                        Home</a></li>
                <li class=" breadcrumb-item active" aria-current="page"> Softwares/POINT OF SALE SOFTWARE SOLUTION </li>
            </ol>
        </nav>
    </div>

    <div class="page-wrapper soft-page">
        <h2>POINT OF SALE SOFTWARE SOLUTION (ADAPACK POS)</h2>

        <div class="row">
            <div class="col-sm-4">
                <img src="../assets/img/adapos.png" alt="ACCOUNTING/FINANCE ERP SOFTWARE">
            </div>

            <div class="col-sm-8">
                <p>


                    Our Integrated adA-Pack POS Software is a stream of locally designed and developed Enterprise
                    Resource Planning Software in Nigeria that caters for all complexity and flexibility required to
                    manage a business outfit such as Supermarkets, Pharmaceutical Stores, Retail and Wholesale Outlets
                    etc. The application is effectively user-friendly, easy-to-use and totally parameter and menu driven
                    with a full set of internal auditing functions that make sure that all data are correctly posted,
                    up-to-date and accurate.
                </p>

                <p>
                The solution package can be configured, integrated and applied to specific needs including but not limited to:
                </p>

                <ul>
                    <li>Sales/Debtor Ledger Control System</li>
                    <li>Accounts Payable System</li>
                    <li>Stock/Inventory Control System</li>
                    



                </ul>
            </div>
        </div>




    </div>
</div>




<?php
require_once '../inc/footer.php';
?>