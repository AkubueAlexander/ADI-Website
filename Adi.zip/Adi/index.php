<?php
$title = 'Adi Systems - Home';


require_once 'inc/header.php';

?>







<!-- Main Section -->
<section class="hero">
    <div class="content">
        <h1>Welcome to ADI Systems Limited</h1>
        <p>Experts In Office ERP Automation & Data Management</p>
    </div>


</section>


<div class="why-choose-us">
    <div class="container">
        <h2>Why Choose Us</h2>
        <div class="row">
            <div class="col-sm-4  software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/customised-report.jpg" class="card-img-top" alt="Customised report">
                    <div class="card-body">
                        <h5 class="card-title">Customised Reports</h5>
                        <p class="card-text">Our ERP software allows you to generate diverse forms of reports which
                            provides
                            insights on how to improve service delivery and reduce costs. This makes your Organisation
                            operate at an efficient level..</p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/user-friendly-interface.jpg" class="card-img-top" alt="user-friendly-interface">
                    <div class="card-body">
                        <h5 class="card-title">User Friendly Interface</h5>
                        <p class="card-text">Our ERP software has a user friendly interface which makes your workforce
                            effective. This in-turn, leaves smiles on the faces of customers due to the timely manner in
                            which our software responds.</p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/application-control.jpg" class="card-img-top" alt="application-control">
                    <div class="card-body">
                        <h5 class="card-title">Application Control</h5>
                        <p class="card-text">Our ERP software allows you to create, restrict and grant access to
                            multiple
                            employees. This makes you monitor and track personnels with just a single click of the
                            button.
                        </p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/advanced-analytics.jpg" class="card-img-top" alt="advanced-analytics">
                    <div class="card-body">
                        <h5 class="card-title">Advanced Analytics</h5>
                        <p class="card-text">Sometimes the best discoveries are the result of simple observations.

                        </p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/customer-insight.png" class="card-img-top" alt="customer-insight">
                    <div class="card-body">
                        <h5 class="card-title">Customer Insights</h5>
                        <p class="card-text">To succeed in business you need to be original, but you also need to
                            understand
                            what your customers want.

                            We are always fine tuning and providing updates to meet customer demands. Ask for a new
                            feature
                            and we deliver ASAP.

                            .</p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/innovation" class="card-img-top" alt="innovation">
                    <div class="card-body">
                        <h5 class="card-title">Innovation</h5>
                        <p class="card-text">We innovate through experimentation.

                            We also evolved from creating programs with Microsoft Disk Operating System (MS-DOS) to ERP
                            software packages that run in browsers and can be accessed on the go, in different branches
                            and
                            department stores when needed.</p>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-4 software">
                <div class="card card-width" style="width: 18rem;">
                    <img src="assets/img/years-experience.jpg" class="card-img-top" alt="years-experience">
                    <div class="card-body">
                        <h5 class="card-title">30 Years Of Experience</h5>
                        <p class="card-text">We are brave. We take risks. We have 30 years worth of experience.</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="our-softwares">
    <div class="container">
        <h2>Our Softwares</h2>

        <div class="row">
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-3"><i class="bi bi-hospital"></i></div>
                    <div class="col-sm-9">
                        <h3>
                            <a href="softwares/medical-healthcare-erp-software-intemeds">Medical/Healthcare ERP Software (INTEMEDS)</a>
                        </h3>
                        <p>
                            iNTEMEDS (Integrated Hospital Management System) is a locally designed and developed
                            Enterprise Resource Planning Software that caters for the complexity and flexibility
                            required to manage a medical practice.

                        </p>
                    </div>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-3"><i class="bi bi-calculator"></i></div>
                    <div class="col-sm-9">
                        <h3><a href="softwares/accounting-finance-erp-software-adapack">Accounting/Finance ERP Software (ADAPACK)</a></h3>
                        <p>
                            ADAPACK (Integrated ERP Acounting Software) is a locally designed and developed Enterprise
                            Resource Planning Software that caters for the complexity and flexibility required to manage
                            a business outfit.

                        </p>
                    </div>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-3"><i class="bi bi-cart-dash"></i></div>
                    <div class="col-sm-9">
                        <h3><a href="softwares/point-of-sale-software-adapack-pos">Point Of Sale Software (ADAPACK POS)</a></h3>
                        <p>
                            ADAPACK-POS (Integrated Point Of Sale Software) is a locally designed and developed
                            Enterprise Resource Planning Software that caters for the complexity and flexibility
                            required to manage business outfits such as Supermarkets, Pharmaceutical Stores, Retail and
                            Wholesale Outlets etc.

                        </p>
                    </div>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-3"><i class="bi bi-building-check"></i></div>
                    <div class="col-sm-9">
                        <h3><a href="softwares/hotel-management-software">Hotel Management Software</a></h3>
                        <p>
                            HOSPICE (Integrated Hotel Management Software) is a locally designed and developed
                            Enterprise Resource Planning Software that caters for the complexity and flexibility
                            required to manage an hospitality business.

                        </p>
                    </div>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-3"><i class="bi bi-capsule"></i></div>
                    <div class="col-sm-9">
                        <h3><a href="softwares/Infertility/Assisted Conception Info. System (ICIS)">Infertility/Assisted Conception Info. System (ICIS)</a></h3>
                        <p>
                            ICIS (Infertility/Assisted Conception Info. System) is a comprehensive Enterprise Resource
                            Planning Software caters for the complexity and flexibility required to manage specialized
                            departments in hospitals

                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<main>




</main>
<script src="assets/js/flow.js"></script>
<?php require_once 'inc/footer.php';?>