<?php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;




function send_email($to,$subject,$first_name, $last_name,$body,$maill){
    //   require 'phpmailer/vendor/autoload.php';
        $mail = $maill;       
        
    try {        
            $mail->isSMTP();
            
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;

            $mail->Host = gethostname();  
          
            $mail->Port = 587;
            
            $mail->SMTPSecure = 'tls';

            $mail->SMTPAuth = true;

           $mail->Username = 'no-reply@einpointinstitute.com';

            $mail->Password = 'zn_-ihB{v&u2';

            $mail->setFrom('no-reply@einpointinstitute.com','Einpoint Institute');
            $mail->addAddress($to, $first_name . ' ' . $last_name);     //Add a recipient 
            
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->AltBody = strip_tags($body);

            $mail->send(); 

           
             
    
    } 
    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}




?>