


let matches = window.matchMedia("(min-width: 750px)").matches;
matches
  ? (options = { threshold: 0.2, rootMargin: "-80px 0px" })
  : (options = { threshold: 0.4, rootMargin: "0px 0px" });
const courseObserver = new IntersectionObserver(
    coursesObserver,
  options
);

function coursesObserver(entries, courseObserver) {
  entries.forEach(entry => {
    if (!entry.isIntersecting) {
      return;
    } else {
      const course = entry.target;
      course.classList.add("smooth-flow");
      courseObserver.unobserve(course);
    }
  });
}

let courses = document.querySelectorAll(".course-plans");
courses.forEach(course => {
  courseObserver.observe(course);
});

