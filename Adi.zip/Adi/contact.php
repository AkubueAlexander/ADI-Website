<?php
//Load Composer's autoloader
require 'phpmailer/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit']) && $_POST['g-recaptcha-response'] != '') {   
    $secret = '6LeRGVcmAAAAAIvs6U1NQttMxpsMwLswvinzLF5z';
    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='. $secret.'&response='.$_POST['g-recaptcha-response']);
    $responseData  = json_decode($verifyResponse);  
    if ($responseData -> success) {
    $email = trim($_POST['email']);
    $id = md5(time().$email);
    $message= trim($_POST['message']);    
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];    
    $subject = $subject;
    $to = $email;
    

    $body = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            color: #333333;
        }
        .content p {
            font-size: 16px;
            line-height: 1.6;
            color: #555555;
        }
        .footer {
            text-align: center;
            font-size: 12px;
            color: #aaaaaa;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='header'>
            <h2>New Message</h2>
        </div>
        <div class='content'>
            <p><strong>My Name:</strong> " . $first_name . " " . $last_name . "</p>
            <p><strong>Email Subject:</strong> " . $subject . "</p>
            <p>" . $message . "</p>
        </div>
        <div class='footer'>
            <p>&copy; " . date('Y') . " Einpoint Institute. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
";
     
    send_email($to,$subject,$first_name, $last_name,$body,new PHPMailer()); 

    }  
    

         

  
    
   
    
}




$title = 'Einpoint  Contact  us';


require_once 'inc/header.php';
?>

<div class="page-banner">
    <img src="assets/img/page-banner.png" alt="Page Banner">
</div>


<div class="container">
    <h2 style="margin:20px 0">Contact us</h2>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index"><span class="fa fa-home"></span>
                    Home</a></li>
            <li class=" breadcrumb-item active" aria-current="page">Contact us</li>
        </ol>
    </nav>
</div>



<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <form action="" method="post">

                <div data-mdb-input-init class="form-outline mb-4">
                    <input type="text" id="first_name" name="first_name" class="form-control" />
                    <label class="form-label" for="first_name">First Name</label>
                </div>

                <div data-mdb-input-init class="form-outline mb-4">
                    <input type="text" id="last_name" name="last_name" class="form-control" />
                    <label class="form-label" for="last_name">Last Name</label>
                </div>
                <div data-mdb-input-init class="form-outline mb-4">
                    <input type="text" id="subject" name="subject" class="form-control" />
                    <label class="form-label" for="subject">Subject</label>
                </div>

                <!-- Message input -->
                <div data-mdb-input-init class="form-outline mb-4">
                    <textarea class="form-control" id="message" name="message" rows="4"></textarea>
                    <label class="form-label" for="message">Message</label>
                </div>



                <!-- Submit button -->
                <button data-mdb-ripple-init type="submit" class="btn btn-primary btn-block mb-4">Send</button>
            </form>
        </div>
        <div class="col-sm-6">
            <p><i class="bi bi-envelope"></i> info@adisystems.com.ng</p>
            <p><i class="bi bi-phone"></i> 080-3529-5090 </p>
            <p><i class="bi bi-phone"></i> 080-2303-2959</p>
            <p><i class="bi bi-phone"></i> 080-7718-5893</p>
            <p><i class="bi bi-geo-alt"></i>156, Okota Road, Okota-Isolo, Lagos, Nigeria.</p>
            <div class="mt-3">
            </div>
        </div>


        
    </div>

    <div class="map-container mb-6">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.0903349641962!2d3.3191968750401313!3d6.510249193482105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b8e93a2fb20f7%3A0x80cab749b062dbc5!2s156%20Okota%20Rd%2C%20Ilasamaja%2C%20Lagos%20102214%2C%20Lagos!5e0!3m2!1sen!2sng!4v1752123271424!5m2!1sen!2sng"
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
</div>
<?php
require_once 'inc/footer.php';
?>