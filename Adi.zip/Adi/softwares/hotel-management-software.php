<?php
$title = 'Einpoint - About';

?>
<?php
require_once 'inc/header.php';
?>


<div class="page-banner">
    <img src="../assets/img/page-banner.png" alt="Page Banner">
</div>
<div class="page-bg">



    <div class="page-wrapper">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index"><span class="fa fa-home"></span>
                        Home</a></li>
                <li class=" breadcrumb-item active" aria-current="page"> COMPLETE HOTEL MANAGEMENT SOLUTION </li>
            </ol>
        </nav>
    </div>

    <div class="page-wrapper soft-page">
        <h2>COMPLETE HOTEL MANAGEMENT SOLUTION (HOSPICE)</h2>

        <div class="row">
            <div class="col-sm-4">
                <img src="../assets/img/hospice.png" alt="COMPLETE HOTEL MANAGEMENT SOLUTION">
            </div>

            <div class="col-sm-8">
                <p>

                    Our Integrated Hotel Management Software (Hospice) is a stream of locally designed and developed
                    Enterprise Resource Planning Software in Nigeria that caters for all complexity and flexibility
                    required to manage a hotel, valuable financial and management information readily available, with
                    minimum hassles, to authorized personnel when required. The systems are designed to fit into small
                    and large Hotels.
                </p>

                <h3>The software includes the following:</h3>

                <ul>
                    <li>Human Resources Management System</li>
                    <li>Purchases/Creditors Ledger System</li>
                    <li>Fixed Assets Management System</li>
                    <li>Sales/Debtor Ledger Control System</li>
                    <li>Stock Control System</li>
                    <li>General Ledger Accounting System</li>


                </ul>

                <p>
                    These programs have been carefully designed to work in a stand-alone system or in a multi-user
                    environment and they can be purchased and used separately or as integrated software.
                </p>
            </div>
        </div>




    </div>
</div>




<?php
require_once '../inc/footer.php';
?>