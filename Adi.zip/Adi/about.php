<?php
$title = 'Einpoint - About';

?>
<?php
require_once 'inc/header.php';
?>


<div class="page-banner">
    <img src="assets/img/page-banner.png" alt="Page Banner">
</div>
<div class="page-bg">



    <div class="page-wrapper">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index"><span class="fa fa-home"></span>
                        Home</a></li>
                <li class=" breadcrumb-item active" aria-current="page">About</li>
            </ol>
        </nav>
    </div>

    <div class="page-wrapper about">
        <h2>WHO WE ARE</h2>
        <div class="about-intro">
            <p>
                We are one of the most trusted & reputable software developers in Nigeria. Our service combines value,
                speed and reliability with a fanatical customer service that is second to none and aimed at customer
                satisfaction. When your software, hardware, and network are integrated and designed properly, the
                workflow and expansion feel natural. Our professionals and their experience take care of the details.
            </p>

            <h2>
                OUR CUSTOMISED SOLUTIONS
            </h2>
            <p>We do not only offer technology, we provide solutions customized for your environment to unite your
                business with customers and vendors.
                The “Adi Systems Approach” has always revolved around its customers satisfaction. We believe technology
                starts with your needs, not ours.</p>

            <h2>
                QUALITY CUSTOMER SERVICE
            </h2>
            <p>

                And we apply the same approach at all stages of your solution’s life cycle; from the assessment to the
                delivery and support of your solution. We do not go into our customers site with one eye closed. Our
                Hardware and Software background has made a whole lot of difference in the quality of services we
                rendered.
            </p>


        </div>


        <div class="smart-approach">
            <h2 class="text-center" style="font-size:1.6em">OUR SMART APPROACH</h2>
            <h3>All progress takes place outside the comfort zone</h3>

            <div class="row">
                <div class="col-sm-4">
                    <div class="card" >
                        <img src="assets/img/smart-1.jpg" class="card-img-top" alt="Smart">
                        <div class="card-body">
                            <h3 class="card-title">GETTING TO KNOW OUR CLIENT’S NEED</h3>
                            <p class="card-text">Collaboration comes first.</p>                            
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="card" >
                        <img src="assets/img/validation.jpg" class="card-img-top" alt="validation">
                        <div class="card-body">
                            <h3 class="card-title">ALWAYS VALIDATION, NEVER ASSUMPTION</h3>
                            <p class="card-text">Always Validation, Never Assumption.</p>                           
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="card" >
                        <img src="assets/img/processss.png" class="card-img-top" alt="ADAPTIVE APPROACH">
                        <div class="card-body">
                            <h3 class="card-title">AN ADAPTIVE APPROACH</h3>
                            <p class="card-text">Research-driven design and Process Built for Progress.</p>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>
</div>




<?php
require_once 'inc/footer.php';
?>