<?php 
define('SITE_NAME', 'https://enpointinstitute.com');


?>